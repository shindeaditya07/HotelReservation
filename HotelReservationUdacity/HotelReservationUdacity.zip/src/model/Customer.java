package model;

import java.util.regex.Pattern;

public class Customer {
    private final String firstName;
    private final String lastName;
    private final String email;

    private static final String email_Regex = "^(.+)@(.+).(.+)";
    private static final Pattern pattern = Pattern.compile(email_Regex);

    public Customer(String firstName, String lastName, String email) {
        if(!Pattern.matches(email_Regex, email)){
            throw new IllegalArgumentException("Wrong email format");
        }
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    @Override
    public String toString(){
        return "Customer First Name: " + firstName + "Last Name: " + lastName + "Email: " + email;
    }
}
