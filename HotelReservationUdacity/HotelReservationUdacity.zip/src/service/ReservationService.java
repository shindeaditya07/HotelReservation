package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {
    private static ReservationService instance;
    private final Map<String, IRoom> rooms = new HashMap<>();
    private final Set<Reservation> reservations = new HashSet<>();

    private ReservationService() {}

    public static ReservationService getInstance(){
        if (instance == null){
            instance = new ReservationService();
        }
        return instance;
    }

    public void addRoom(IRoom room){
        rooms.put(room.getRoomNumber(), room);
    }

    public IRoom getARoom(String roomId){
        return rooms.get(roomId);
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkinDate, Date checkoutDate){
        Reservation reservation = new Reservation(customer, room, checkinDate, checkoutDate);
        reservations.add(reservation);
        return reservation;
    }

    public Collection<IRoom> findRooms (Date checkinDate, Date checkoutDate){
        List<IRoom> availableRooms = new ArrayList<>(rooms.values());
        for (Reservation reservation : reservations){
            if(!(checkoutDate.before(reservation.getCheckinDate()) || checkinDate.after(reservation.getCheckoutDate()))){
                availableRooms.remove(reservation.getRoom());
            }
        }
    return availableRooms;
    }

    public Collection<Reservation> getCustomersReservation(Customer customer){
        List<Reservation> customerReservations = new ArrayList<>();
        for (Reservation reservation : reservations){
            if(reservation.getCustomer().equals(customer)){
                System.out.println(reservation);
            }
        }
        return customerReservations;
    }

    public void printAllReservation(){
        for (Reservation reservation : reservations){
            System.out.println(reservation);
        }
    }

    public Collection<IRoom> getAllRooms() {
        return rooms.values();
    }
}
