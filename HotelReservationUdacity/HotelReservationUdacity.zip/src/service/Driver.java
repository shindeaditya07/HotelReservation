package service;

import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.util.Date;

public class Driver {
    public static void main(String[] args) {
        CustomerService customerService = CustomerService.getInstance();
        ReservationService reservationService = ReservationService.getInstance();

        customerService.addCustomer("shindeaditya07@gmail.com", "Aditya", "Shinde");
        customerService.addCustomer("test@example.com", "John", "Doe");

        System.out.println("Customers: ");
        for (Customer customer : customerService.getAllCustomers()){
            System.out.println(customer);
        }

        IRoom room1 = new Room("101", 200.0, RoomType.SINGLE);
        IRoom room2 = new Room("102", 300.0, RoomType.DOUBLE);
        reservationService.addRoom(room1);
        reservationService.addRoom(room2);

        Customer customer = customerService.getCustomer("shindeaditya07@gmail.com");
        Date checkinDate = new Date();
        Date checkoutDate = new Date();

        reservationService.reserveARoom(customer, room1, checkinDate, checkoutDate);

        System.out.println("\nReservations:");
        reservationService.printAllReservation();
    }
}
